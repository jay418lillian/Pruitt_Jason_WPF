/**
Jason Pruitt
 3-5-15
 SDI
 C201503
 */

var shotPercentage = 55.72;         //number data type
var basketball = true;              //boolean data type
var myName = "Jason Pruitt";        //string data type

console.log("Hello, My name is " + myName + " and I am glad to be here!");                                                  //concatenating using the string variable
console.log("I enjoy playing basketball on the weekends, and have a shooting percentage of " + shotPercentage + "%.");      //concatenating the number data type to the console
console.log("I have played basketball all of my life and it is " + basketball + " that I play in an adult league.");        //concatenating using the boolean value